<?php
error_reporting(0);
$access = $_POST['access'];
if($_POST['access']){
  echo "abfbb042bf354b45965a4a3135f40224";
}
?>
