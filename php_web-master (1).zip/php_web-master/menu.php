<link rel="stylesheet" type="text/css" href="style.css" />
<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1>Bot Center -  Control Room</h1>
			</div>
		</div>
	</div>

<!--close-Header-part-->

<div class="container">
	<nav>
		<ul class="mcd-menu">
		<li>
		<a href="#">Bot Analytics</a>
		<ul>
				<li><a href="https://www.dashbot.io/login">Dashbot Analytics</a></li>
			
		</ul>
	</li>
	<li>
		<a href="#">Training Bot</a>
		<ul>
			<li>
				<a href="https://console.api.ai/api-client/#/login">API.AI</a>
			</li>
			
		</ul>
	</li>
	<li>
		<a href="#">Business Cases</a>
		<ul>
			 <li> <a href="index.php">Top Selling Offers</a></li>
			 <li><a href="fb_campaign.php">Broadcast to FB users</a></li>
			 <li><a href="fb_campaign_aws.php">Broadcast to FB users via AWS</a></li>
			 <li><a href="poc_voice.php">POC for voice</a></li>
		</ul>
	</li>
	<li>
		<a href="#">Controls</a>
		<ul>
			<li>
				<a href="logout.php">Sign Out</a>
			</li>
			
		</ul>
	</li>
</ul>
	</nav>
 	    <!--<div id="body" class="clear">
			<div id="sidebar" class="column-left">
			<ul>
                	<li>
			<h4>Bot Performance and Analytics</h4>
                        <ul class="blocklist">
                            <li><a href="https://www.dashbot.io/login">Dashbot Analytics</a></li>                            
                        </ul>
			</li>
			<li>
			<h4>Bot Training</h4>
                        <ul class="blocklist">
                            <li><a href="https://console.api.ai/api-client/#/login">API.AI</a></li>
                           </ul>
			</li>
			<li>
			<h4>Business Usecases</h4>
                        <ul class="blocklist">
                            <li><a href="index.php">Top Selling Offers</a></li>
			    <li><a href="fb_campaign.php">Broadcast to FB users</a></li>
                           </ul>
			</li>
			<li>
			<h4>Session Controls</h4>
                        <ul class="blocklist">
                            <li><a href="logout.php">Sign Out</a></li>
			                    </ul>
			</li>
			</ul>
			</div>
<!-- CHANGE ENDS here -->
